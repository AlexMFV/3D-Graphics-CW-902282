function defaults = setGlobalVars()
%--------- Glob Variables ----------
defaults.camHeight = 7;
defaults.degPerPixel = 0.042;
defaults.screenX = 480;
defaults.screenY = 640;
defaults.convertMph = 2.23693629;
%-------- /Glob Variables -----------